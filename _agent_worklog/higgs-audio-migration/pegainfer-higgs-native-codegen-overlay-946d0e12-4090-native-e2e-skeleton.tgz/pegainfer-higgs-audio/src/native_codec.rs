use std::collections::BTreeMap;
use std::collections::BTreeSet;
use std::collections::HashMap;
use std::io::Read;
use std::path::Path;

use anyhow::Context;
use anyhow::Result;
use anyhow::bail;
use anyhow::ensure;
use serde::Deserialize;
use serde_json::Value;

use crate::codec_input::CODEC_AUDIO_VOCAB_SIZE;
use crate::one_step_golden::CODEBOOK_VOCAB_SIZE;
use crate::one_step_golden::NUM_CODEBOOKS;
use crate::weights::HiggsWeightManifest;

pub const CODEC_TTS_PREFIX: &str = "tied.embedding.modality_embeddings.0.model.";
pub const NATIVE_CODEC_CLAIM: &str = "native_codec_contract_only_no_waveform";

const BUNDLED_CODEC_CONFIG: &str =
    include_str!("../../tools/higgs/configs/higgs_audio_v2_tokenizer.json");

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NativeCodecConfig {
    pub sample_rate: usize,
    pub hop_length: usize,
    pub frame_rate: usize,
    pub num_quantizers: usize,
    pub codebook_size: usize,
    pub codebook_dim: usize,
    pub decoder_hidden_size: usize,
    pub upsampling_ratios: Vec<usize>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NativeCodecTensorSpec {
    pub full_name: String,
    pub codec_name: String,
    pub dtype: &'static str,
    pub shape: Vec<usize>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NativeCodecManifestSummary {
    pub codec_tensors_in_manifest: usize,
    pub required_tensors_checked: usize,
    pub files_checked: usize,
}

#[derive(Debug, Clone, PartialEq)]
pub struct NativePcmAudio {
    pub sample_rate: usize,
    pub samples: Vec<f32>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NativeCodecBackend {
    CudaSkeleton,
}

#[derive(Debug, Clone)]
pub struct NativeHiggsCodecDecoder {
    config: NativeCodecConfig,
    backend: NativeCodecBackend,
}

#[derive(Debug, Deserialize)]
struct RawCodecConfig {
    sample_rate: usize,
    codebook_size: usize,
    codebook_dim: usize,
    acoustic_model_config: RawAcousticModelConfig,
}

#[derive(Debug, Deserialize)]
struct RawAcousticModelConfig {
    decoder_hidden_size: usize,
    hop_length: usize,
    upsampling_ratios: Vec<usize>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct TensorHeader {
    dtype: String,
    shape: Vec<usize>,
    byte_range: [usize; 2],
}

impl NativeCodecConfig {
    pub fn bundled_higgs_v2() -> Result<Self> {
        let raw: RawCodecConfig = serde_json::from_str(BUNDLED_CODEC_CONFIG)
            .context("parse bundled Higgs codec config")?;
        ensure!(raw.sample_rate > 0, "codec sample_rate must be positive");
        ensure!(
            raw.acoustic_model_config.hop_length > 0,
            "codec hop_length must be positive"
        );
        ensure!(
            raw.sample_rate % raw.acoustic_model_config.hop_length == 0,
            "codec sample_rate must be divisible by hop_length"
        );
        ensure!(
            raw.codebook_size == CODEBOOK_VOCAB_SIZE - 2,
            "codec codebook_size mismatch: expected {}, got {}",
            CODEBOOK_VOCAB_SIZE - 2,
            raw.codebook_size
        );
        ensure!(
            raw.codebook_dim == 64,
            "Higgs native codec skeleton expects codebook_dim=64, got {}",
            raw.codebook_dim
        );
        Ok(Self {
            sample_rate: raw.sample_rate,
            hop_length: raw.acoustic_model_config.hop_length,
            frame_rate: raw.sample_rate / raw.acoustic_model_config.hop_length,
            num_quantizers: NUM_CODEBOOKS,
            codebook_size: raw.codebook_size,
            codebook_dim: raw.codebook_dim,
            decoder_hidden_size: raw.acoustic_model_config.decoder_hidden_size,
            upsampling_ratios: raw.acoustic_model_config.upsampling_ratios,
        })
    }
}

impl NativeHiggsCodecDecoder {
    pub fn from_model_dir(
        model_dir: impl AsRef<Path>,
        backend: NativeCodecBackend,
    ) -> Result<Self> {
        let config = NativeCodecConfig::bundled_higgs_v2()?;
        let manifest = HiggsWeightManifest::from_model_dir(&model_dir)?;
        validate_native_codec_manifest(model_dir, &manifest, &config)?;
        Ok(Self { config, backend })
    }

    pub fn config(&self) -> &NativeCodecConfig {
        &self.config
    }

    pub fn decode_raw_codes(&self, raw_codes: &[Vec<u32>]) -> Result<NativePcmAudio> {
        validate_raw_codec_rows(raw_codes, &self.config)?;
        match self.backend {
            NativeCodecBackend::CudaSkeleton => bail!(
                "Higgs native codec CUDA decoder is not implemented yet; claim boundary is {NATIVE_CODEC_CLAIM}"
            ),
        }
    }
}

pub fn validate_raw_codec_rows(rows: &[Vec<u32>], config: &NativeCodecConfig) -> Result<()> {
    ensure!(
        !rows.is_empty(),
        "native codec requires at least one raw codec frame"
    );
    for (row_idx, row) in rows.iter().enumerate() {
        ensure!(
            row.len() == config.num_quantizers,
            "raw codec row {row_idx} has {} quantizers, expected {}",
            row.len(),
            config.num_quantizers
        );
        for (codebook, code) in row.iter().enumerate() {
            ensure!(
                *code < CODEC_AUDIO_VOCAB_SIZE,
                "raw codec row {row_idx} codebook {codebook} has code {code}, expected < {CODEC_AUDIO_VOCAB_SIZE}"
            );
        }
    }
    Ok(())
}

pub fn expected_native_codec_tensor_specs(
    config: &NativeCodecConfig,
) -> Vec<NativeCodecTensorSpec> {
    let required = [
        (
            "quantizer.quantizers.0.codebook.embed",
            vec![config.codebook_size, config.codebook_dim],
        ),
        (
            "quantizer.quantizers.7.codebook.embed",
            vec![config.codebook_size, config.codebook_dim],
        ),
        (
            "acoustic_decoder.block.0.conv_t1.weight",
            vec![config.decoder_hidden_size, 512, 16],
        ),
    ];
    required
        .into_iter()
        .map(|(codec_name, shape)| NativeCodecTensorSpec {
            full_name: format!("{CODEC_TTS_PREFIX}{codec_name}"),
            codec_name: codec_name.to_string(),
            dtype: "F32",
            shape,
        })
        .collect()
}

pub fn validate_native_codec_manifest(
    model_dir: impl AsRef<Path>,
    manifest: &HiggsWeightManifest,
    config: &NativeCodecConfig,
) -> Result<NativeCodecManifestSummary> {
    let codec_tensors_in_manifest = manifest
        .weight_map
        .keys()
        .filter(|name| name.starts_with(CODEC_TTS_PREFIX))
        .count();
    ensure!(
        codec_tensors_in_manifest >= 527,
        "Higgs codec manifest is too sparse: found {codec_tensors_in_manifest} tensors with prefix {CODEC_TTS_PREFIX:?}"
    );

    let specs = expected_native_codec_tensor_specs(config);
    let mut by_file: BTreeMap<String, Vec<&NativeCodecTensorSpec>> = BTreeMap::new();
    for spec in &specs {
        let file = manifest
            .weight_map
            .get(&spec.full_name)
            .with_context(|| format!("manifest missing native codec tensor {}", spec.full_name))?;
        by_file.entry(file.clone()).or_default().push(spec);
    }

    for (file, specs) in &by_file {
        let header = read_safetensors_header(&model_dir.as_ref().join(file))?;
        for spec in specs {
            let actual = header
                .get(&spec.full_name)
                .with_context(|| format!("{file} missing tensor {}", spec.full_name))?;
            ensure!(
                actual.dtype == spec.dtype,
                "{} dtype mismatch: expected {}, got {}",
                spec.full_name,
                spec.dtype,
                actual.dtype
            );
            ensure!(
                actual.shape == spec.shape,
                "{} shape mismatch: expected {:?}, got {:?}",
                spec.full_name,
                spec.shape,
                actual.shape
            );
            ensure!(
                actual.byte_range[0] <= actual.byte_range[1],
                "{} has invalid data_offsets {:?}",
                spec.full_name,
                actual.byte_range
            );
        }
    }

    Ok(NativeCodecManifestSummary {
        codec_tensors_in_manifest,
        required_tensors_checked: specs.len(),
        files_checked: by_file.len(),
    })
}

pub fn write_pcm16_wav(path: impl AsRef<Path>, audio: &NativePcmAudio) -> Result<()> {
    ensure!(audio.sample_rate > 0, "sample_rate must be positive");
    let data_bytes = audio.samples.len() * 2;
    let riff_size = 36usize
        .checked_add(data_bytes)
        .context("wav size overflow")?;
    let mut bytes = Vec::with_capacity(44 + data_bytes);
    bytes.extend_from_slice(b"RIFF");
    bytes.extend_from_slice(&(riff_size as u32).to_le_bytes());
    bytes.extend_from_slice(b"WAVEfmt ");
    bytes.extend_from_slice(&16u32.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&(audio.sample_rate as u32).to_le_bytes());
    bytes.extend_from_slice(&((audio.sample_rate * 2) as u32).to_le_bytes());
    bytes.extend_from_slice(&2u16.to_le_bytes());
    bytes.extend_from_slice(&16u16.to_le_bytes());
    bytes.extend_from_slice(b"data");
    bytes.extend_from_slice(&(data_bytes as u32).to_le_bytes());
    for sample in &audio.samples {
        let clamped = if sample.is_finite() {
            sample.clamp(-1.0, 1.0)
        } else {
            0.0
        };
        bytes.extend_from_slice(&((clamped * 32767.0).round() as i16).to_le_bytes());
    }
    std::fs::write(path.as_ref(), bytes)
        .with_context(|| format!("write {}", path.as_ref().display()))
}

fn read_safetensors_header(path: &Path) -> Result<HashMap<String, TensorHeader>> {
    let mut file = std::fs::File::open(path).with_context(|| format!("open {}", path.display()))?;
    let mut len_bytes = [0u8; 8];
    file.read_exact(&mut len_bytes)
        .with_context(|| format!("read safetensors header length from {}", path.display()))?;
    let header_len = usize::try_from(u64::from_le_bytes(len_bytes)).with_context(|| {
        format!(
            "{} safetensors header length does not fit usize",
            path.display()
        )
    })?;
    ensure!(
        header_len < 512 * 1024 * 1024,
        "{} safetensors header is unexpectedly large: {} bytes",
        path.display(),
        header_len
    );
    let mut header_bytes = vec![0u8; header_len];
    file.read_exact(&mut header_bytes)
        .with_context(|| format!("read safetensors header from {}", path.display()))?;
    let value: Value = serde_json::from_slice(&header_bytes)
        .with_context(|| format!("parse safetensors header from {}", path.display()))?;
    let object = value
        .as_object()
        .with_context(|| format!("{} safetensors header is not a JSON object", path.display()))?;
    let mut tensors = HashMap::new();
    for (name, value) in object {
        if name == "__metadata__" {
            continue;
        }
        let dtype = value
            .get("dtype")
            .and_then(Value::as_str)
            .with_context(|| format!("{name} missing dtype"))?
            .to_string();
        let shape = value
            .get("shape")
            .and_then(Value::as_array)
            .with_context(|| format!("{name} missing shape"))?
            .iter()
            .map(|dim| {
                dim.as_u64()
                    .context("shape dim is not u64")
                    .and_then(|dim| usize::try_from(dim).context("shape dim does not fit usize"))
            })
            .collect::<Result<Vec<_>>>()?;
        let offsets = value
            .get("data_offsets")
            .and_then(Value::as_array)
            .with_context(|| format!("{name} missing data_offsets"))?;
        ensure!(offsets.len() == 2, "{name} data_offsets must have length 2");
        let start = offsets[0]
            .as_u64()
            .with_context(|| format!("{name} data_offsets[0] is not u64"))
            .and_then(|offset| usize::try_from(offset).context("offset does not fit usize"))?;
        let end = offsets[1]
            .as_u64()
            .with_context(|| format!("{name} data_offsets[1] is not u64"))
            .and_then(|offset| usize::try_from(offset).context("offset does not fit usize"))?;
        tensors.insert(
            name.clone(),
            TensorHeader {
                dtype,
                shape,
                byte_range: [start, end],
            },
        );
    }
    Ok(tensors)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bundled_codec_config_matches_higgs_v2_decode_contract() {
        let config = NativeCodecConfig::bundled_higgs_v2().unwrap();
        assert_eq!(config.sample_rate, 24_000);
        assert_eq!(config.hop_length, 960);
        assert_eq!(config.frame_rate, 25);
        assert_eq!(config.num_quantizers, 8);
        assert_eq!(config.codebook_size, 1024);
        assert_eq!(config.codebook_dim, 64);
        assert_eq!(config.decoder_hidden_size, 1024);
        assert_eq!(config.upsampling_ratios, [8, 5, 4, 2, 3]);
    }

    #[test]
    fn expected_specs_pin_reference_decoder_surface() {
        let config = NativeCodecConfig::bundled_higgs_v2().unwrap();
        let specs = expected_native_codec_tensor_specs(&config);
        assert!(specs.iter().any(|spec| {
            spec.full_name
                == "tied.embedding.modality_embeddings.0.model.quantizer.quantizers.0.codebook.embed"
                && spec.shape == [1024, 64]
        }));
        assert!(specs.iter().any(|spec| {
            spec.full_name
                == "tied.embedding.modality_embeddings.0.model.acoustic_decoder.block.0.conv_t1.weight"
                && spec.shape == [1024, 512, 16]
        }));
    }

    #[test]
    fn raw_codec_rows_reject_sentinels_before_native_decode() {
        let config = NativeCodecConfig::bundled_higgs_v2().unwrap();
        let err = validate_raw_codec_rows(&[vec![0, 1, 2, 3, 4, 5, 6, 1024]], &config)
            .unwrap_err()
            .to_string();
        assert!(err.contains("expected < 1024"));
    }

    #[test]
    fn cuda_skeleton_is_fail_closed() {
        let decoder = NativeHiggsCodecDecoder {
            config: NativeCodecConfig::bundled_higgs_v2().unwrap(),
            backend: NativeCodecBackend::CudaSkeleton,
        };
        let err = decoder
            .decode_raw_codes(&[vec![0, 1, 2, 3, 4, 5, 6, 7]])
            .unwrap_err()
            .to_string();
        assert!(err.contains(NATIVE_CODEC_CLAIM));
    }

    #[test]
    fn wav_writer_emits_pcm16_header() {
        let dir = tempfile::TempDir::new().unwrap();
        let path = dir.path().join("out.wav");
        write_pcm16_wav(
            &path,
            &NativePcmAudio {
                sample_rate: 24_000,
                samples: vec![0.0, 0.5, -0.5],
            },
        )
        .unwrap();
        let bytes = std::fs::read(path).unwrap();
        assert_eq!(&bytes[0..4], b"RIFF");
        assert_eq!(&bytes[8..12], b"WAVE");
        assert_eq!(bytes.len(), 50);
    }

    #[test]
    fn manifest_validation_rejects_sparse_codec_surface() {
        let config = NativeCodecConfig::bundled_higgs_v2().unwrap();
        let mut weight_map = HashMap::new();
        weight_map.insert(
            format!("{CODEC_TTS_PREFIX}quantizer.quantizers.0.codebook.embed"),
            "model.safetensors".to_string(),
        );
        let manifest = HiggsWeightManifest {
            total_size: None,
            weight_map,
        };
        let err = validate_native_codec_manifest(".", &manifest, &config)
            .unwrap_err()
            .to_string();
        assert!(err.contains("too sparse"));
    }

    #[test]
    fn all_expected_specs_are_unique() {
        let config = NativeCodecConfig::bundled_higgs_v2().unwrap();
        let specs = expected_native_codec_tensor_specs(&config);
        let names: BTreeSet<_> = specs.iter().map(|spec| spec.full_name.as_str()).collect();
        assert_eq!(names.len(), specs.len());
    }
}
